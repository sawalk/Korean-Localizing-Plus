stringtable.sta는 아이작의 번제의 아이템 이름, 설명,
몬스터 이름 등 게임 내 문자열을 저장하는 파일입니다.

그러나, stringtable.sta는 공식적으로 모딩을 지원하지 않습니다.

그리하여 한국어 번역+ 모드는 lua 모딩으로
아이템 이름을 수정하는 방법을 채택했으나, 이 또한
한계점이 있어 완벽한 수정이 불가능합니다.

이 압축 파일은 이러한 점을 보완하려 하는 유저분들을
위한 파일입니다. 아래 지시를 따라 stringtable.sta를 복사하세요.

=======================================================================

압축 파일 내 resources-dlc3 폴더를 복사하고
"..common\The Binding of Isaac Rebirth"에 복사하세요.

이미 폴더가 존재하는 경우, stringtable.sta만 복사하여
"..common\The Binding of Isaac Rebirth\resources-dlc3"에 복사하세요.